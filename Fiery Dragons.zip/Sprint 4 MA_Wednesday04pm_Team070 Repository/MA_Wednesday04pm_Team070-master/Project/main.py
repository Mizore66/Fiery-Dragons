from game.game import Game

# Author: Aditti Gupta (32863357)
# Create a game instance and run it
Game().run()